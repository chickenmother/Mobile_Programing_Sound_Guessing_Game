define( function() {

"use strict";

return ( /HTML$/i );

} );
